'use strict';
(function(){
 const dot=document.getElementById('cursor');
 if(!dot)return;
 document.addEventListener('mousemove',e=>{
 dot.style.left=e.clientX+'px';
 dot.style.top=e.clientY+'px';
},{passive: true});
 document.addEventListener('mouseleave',()=>{dot.style.opacity='0';});
 document.addEventListener('mouseenter',()=>{dot.style.opacity='1';});
})();
(function(){
 const nav=document.querySelector('.nav');
 const burger=document.getElementById('nav-burger');
 const drawer=document.getElementById('nav-drawer');
 const overlay=document.getElementById('nav-overlay');
 window.addEventListener('scroll',()=>{
 if(nav)nav.classList.toggle('scrolled',window.scrollY>50);
},{passive: true});
 function openDrawer(){
 drawer&&drawer.classList.add('open');
 overlay&&overlay.classList.add('show');
 burger&&burger.classList.add('open');
 burger&&burger.setAttribute('aria-expanded','true');
 document.body.style.overflow='hidden';
}
 function closeDrawer(){
 drawer&&drawer.classList.remove('open');
 overlay&&overlay.classList.remove('show');
 burger&&burger.classList.remove('open');
 burger&&burger.setAttribute('aria-expanded','false');
 document.body.style.overflow='';
}
 burger&&burger.addEventListener('click',()=>
 drawer&&drawer.classList.contains('open')? closeDrawer(): openDrawer()
);
 overlay&&overlay.addEventListener('click',closeDrawer);
 drawer&&drawer.querySelectorAll('a').forEach(a=>a.addEventListener('click',closeDrawer));
})();
document.querySelectorAll('a[href^="#"]').forEach(a=>{
 a.addEventListener('click',e=>{
 const target=document.querySelector(a.getAttribute('href'));
 if(target){
 e.preventDefault();
 target.scrollIntoView({behavior: 'smooth'});
}
});
});
(function(){
 const io=new IntersectionObserver(entries=>{
 entries.forEach(e=>{
 if(e.isIntersecting){
 e.target.classList.add('visible');
 io.unobserve(e.target);
}
});
},{threshold: 0.1,rootMargin: '0px 0px -40px 0px'});
 document.querySelectorAll('.reveal').forEach(el=>io.observe(el));
})();
(function(){
 const io=new IntersectionObserver(entries=>{
 entries.forEach(e=>{
 if(!e.isIntersecting)return;
 const el=e.target;
 const end=+el.dataset.count;
 const sfx=el.dataset.suffix||'';
 const dur=1600;
 const t0=performance.now();
(function tick(now){
 const p=Math.min((now-t0)/ dur,1);
 const v=Math.floor((1-Math.pow(1-p,3))*end);
 el.textContent=v+sfx;
 if(p<1)requestAnimationFrame(tick);
})(t0);
 io.unobserve(el);
});
},{threshold: 0.5});
 document.querySelectorAll('[data-count]').forEach(el=>io.observe(el));
})();
document.querySelectorAll('.svc-expand-btn').forEach(btn=>{
 btn.addEventListener('click',()=>{
 const panel=btn.nextElementSibling;
 const open=panel.classList.toggle('open');
 btn.classList.toggle('open',open);
 btn.setAttribute('aria-expanded',String(open));
 btn.querySelector('.expand-label').textContent=open ? 'Collapse' : 'Details';
});
});
(function(){
 const cv=document.getElementById('starfield');
 if(!cv)return;
 const ctx=cv.getContext('2d');
 let W,H;
 function resize(){
 W=cv.width=window.innerWidth;
 H=cv.height=window.innerHeight;
}
 resize();
 window.addEventListener('resize',resize,{passive: true});
 const FIELD=3600;
 const layers=[
{n: 500,rMin: 0.15,rMax: 0.6,sp: 0.12,opMin: 0.12,opMax: 0.4,col: '200,220,255'},
{n: 220,rMin: 0.5,rMax: 1.3,sp: 0.4,opMin: 0.28,opMax: 0.7,col: '210,235,255'},
{n: 60,rMin: 1.1,rMax: 2.0,sp: 0.85,opMin: 0.45,opMax: 0.95,col: '220,245,255'},
 ];
 const stars=layers.flatMap(l=>
 Array.from({length: l.n},()=>({
 x: Math.random()*FIELD,y: Math.random()*FIELD,
 r: l.rMin+Math.random()*(l.rMax-l.rMin),
 op: l.opMin+Math.random()*(l.opMax-l.opMin),
 tw: Math.random()*0.018+0.004,
 ph: Math.random()*Math.PI*2,
 sp: l.sp,col: l.col,
 glow: Math.random()<0.12,
}))
);
 const nebulas=Array.from({length: 4},()=>({
 x: Math.random()*FIELD,y: Math.random()*FIELD,
 r: 180+Math.random()*350,
 r2: Math.floor(Math.random()*30),
 g2: Math.floor(Math.random()*70+30),
 b2: Math.floor(Math.random()*110+70),
 op: 0.025+Math.random()*0.05,
 sp: 0.07+Math.random()*0.09,
}));
 let camX=0,camY=0,dA=0,t=0;
 const DS=0.1,TS=0.00012;
 function wrap(v){return((v % FIELD)+FIELD)% FIELD;}
(function draw(){
 t+=0.014;
 dA+=Math.sin(t*0.05)*TS;
 camX=wrap(camX+Math.cos(dA)*DS);
 camY=wrap(camY+Math.sin(dA)*DS);
 ctx.clearRect(0,0,W,H);
 nebulas.forEach(n=>{
 const nx=wrap(n.x-camX*n.sp);
 const ny=wrap(n.y-camY*n.sp);
 const g=ctx.createRadialGradient(nx,ny,0,nx,ny,n.r);
 g.addColorStop(0,`rgba(${n.r2},${n.g2},${n.b2},${n.op})`);
 g.addColorStop(1,'transparent');
 ctx.fillStyle=g;
 ctx.beginPath();ctx.arc(nx,ny,n.r,0,Math.PI*2);ctx.fill();
});
 stars.forEach(s=>{
 const sx=wrap(s.x-camX*s.sp);
 const sy=wrap(s.y-camY*s.sp);
 if(sx<-5||sx>W+5||sy<-5||sy>H+5)return;
 const tw=Math.sin(t*s.tw*60+s.ph)*0.25+0.75;
 ctx.globalAlpha=s.op*tw;
 if(s.glow){
 const g=ctx.createRadialGradient(sx,sy,0,sx,sy,s.r*3.5);
 g.addColorStop(0,`rgba(${s.col},${s.op*tw})`);
 g.addColorStop(1,`rgba(${s.col},0)`);
 ctx.fillStyle=g;
 ctx.beginPath();ctx.arc(sx,sy,s.r*3.5,0,Math.PI*2);ctx.fill();
}
 ctx.fillStyle=`rgba(${s.col},1)`;
 ctx.beginPath();ctx.arc(sx,sy,s.r,0,Math.PI*2);ctx.fill();
});
 ctx.globalAlpha=1;
 requestAnimationFrame(draw);
})();
})();
(function(){
 const cv=document.getElementById('name-sparks');
 const title=document.querySelector('.hero-name');
 if(!cv||!title)return;
 const ctx=cv.getContext('2d');
 function resize(){
 const r=title.getBoundingClientRect();
 cv.width=r.width;
 cv.height=r.height;
}
 resize();
 window.addEventListener('resize',resize,{passive: true});
 const particles=[];
 let nextBurst=0;
 function spawnBurst(){
 const tr=title.getBoundingClientRect();
 const x=Math.random()*tr.width;
 const y=Math.random()*tr.height;
 const n=Math.floor(Math.random()*5)+3;
 for(let i=0;i<n;i++){
 const a=Math.random()*Math.PI*2;
 const v=Math.random()*3.5+1;
 particles.push({
 x,y,
 vx: Math.cos(a)*v,
 vy: Math.sin(a)*v,
 life: 1,
 decay: Math.random()*0.025+0.015,
 size: Math.random()*2.2+0.5,
 gy: 0.05+Math.random()*0.035,
 drag: 0.96+Math.random()*0.02,
 col: Math.random()<0.65 ? '0,229,255' : '255,255,255',
 trail: [],
});
}
}
(function loop(ts){
 const r=title.getBoundingClientRect();
 if(Math.round(cv.width)!==Math.round(r.width))resize();
 ctx.clearRect(0,0,cv.width,cv.height);
 if(ts>=nextBurst){
 spawnBurst();
 nextBurst=ts+120+Math.random()*600;
}
 for(let i=particles.length-1;i>=0;i--){
 const p=particles[i];
 p.trail.push({x: p.x,y: p.y});
 if(p.trail.length>10)p.trail.shift();
 p.x+=p.vx;p.y+=p.vy;
 p.vx*=p.drag;p.vy*=p.drag;
 p.vy+=p.gy;
 p.life-=p.decay;
 if(p.life<=0){particles.splice(i,1);continue;}
 for(let j=1;j<p.trail.length;j++){
 const a=p.trail[j-1],b=p.trail[j];
 ctx.beginPath();ctx.moveTo(a.x,a.y);ctx.lineTo(b.x,b.y);
 ctx.strokeStyle=`rgba(${p.col},${(j / p.trail.length)*p.life*0.4})`;
 ctx.lineWidth=p.size*(j / p.trail.length)*0.65;
 ctx.lineCap='round';
 ctx.stroke();
}
 const g=ctx.createRadialGradient(p.x,p.y,0,p.x,p.y,p.size*4.5);
 g.addColorStop(0,`rgba(${p.col},${p.life*0.4})`);
 g.addColorStop(1,'transparent');
 ctx.fillStyle=g;
 ctx.beginPath();ctx.arc(p.x,p.y,p.size*4.5,0,Math.PI*2);ctx.fill();
 ctx.beginPath();ctx.arc(p.x,p.y,p.size*p.life,0,Math.PI*2);
 ctx.fillStyle=`rgba(${p.col},${Math.min(p.life*1.4,1)})`;
 ctx.fill();
 if(p.life>0.6&&p.size>1.0){
 const sl=p.size*8*p.life;
 ctx.save();
 ctx.strokeStyle=`rgba(${p.col},${p.life*0.6})`;
 ctx.lineWidth=0.7;ctx.lineCap='round';
 ctx.beginPath();ctx.moveTo(p.x-sl,p.y);ctx.lineTo(p.x+sl,p.y);ctx.stroke();
 ctx.beginPath();ctx.moveTo(p.x,p.y-sl);ctx.lineTo(p.x,p.y+sl);ctx.stroke();
 ctx.restore();
}
}
 requestAnimationFrame(loop);
})(0);
})();
(function(){
 const cv=document.getElementById('starfield');
 if(!cv)return;
 const ctx=cv.getContext('2d');
 const pts=[];
 const COLS=['0,229,255','255,255,255','129,212,250','0,180,220','255,220,100'];
 let running=false;
 function addP(x,y,vx,vy,life,decay,size,colIdx,drag){
 pts.push({x,y,vx,vy,life,decay: decay||0.02,size: size||3,colIdx: colIdx||0,drag: drag||0.96,gy: 0.05});
}
 function animPts(){
 for(let i=pts.length-1;i>=0;i--){
 const p=pts[i];
 p.x+=p.vx;p.y+=p.vy;
 p.vx*=p.drag;p.vy*=p.drag;
 p.vy+=p.gy;
 p.life-=p.decay;
 if(p.life<=0){pts.splice(i,1);continue;}
 const c=COLS[p.colIdx]||COLS[0];
 ctx.save();
 ctx.globalAlpha=Math.min(p.life,1);
 const g=ctx.createRadialGradient(p.x,p.y,0,p.x,p.y,p.size*p.life);
 g.addColorStop(0,`rgba(${c},${p.life})`);
 g.addColorStop(1,`rgba(${c},0)`);
 ctx.fillStyle=g;
 ctx.beginPath();ctx.arc(p.x,p.y,p.size*p.life,0,Math.PI*2);ctx.fill();
 ctx.restore();
}
 if(pts.length>0){
 requestAnimationFrame(animPts);
}else{
 running=false;
}
}
 function fire(cx,cy){
 for(let i=0;i<24;i++){
 const a=Math.random()*Math.PI*2,sp=Math.random()*7+2;
 addP(cx,cy,Math.cos(a)*sp,Math.sin(a)*sp,1,
 Math.random()*0.03+0.02,Math.random()*8+2,
 Math.floor(Math.random()*COLS.length),0.9+Math.random()*0.06);
}
 for(let i=0;i<8;i++){
 const a=Math.random()*Math.PI*2,sp=Math.random()*10+4;
 addP(cx,cy,Math.cos(a)*sp,Math.sin(a)*sp,1,
 Math.random()*0.04+0.025,Math.random()*4+1,
 Math.floor(Math.random()*2),0.88+Math.random()*0.05);
}
 if(!running){running=true;requestAnimationFrame(animPts);}
}
 window.addEventListener('click',e=>fire(e.clientX,e.clientY));
 window.addEventListener('touchstart',e=>{
 const t=e.touches[0];
 fire(t.clientX,t.clientY);
},{passive: true});
})();