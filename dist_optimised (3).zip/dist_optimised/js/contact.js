'use strict';
(function(){
 const form=document.getElementById('contact-form');
 const btn=document.getElementById('form-btn');
 const status=document.getElementById('form-status');
 if(!form||!btn||!status)return;
 const label=btn.querySelector('.btn-label');
 const spinner=btn.querySelector('.spinner');
 let lastFormData;
 const waCta=document.getElementById('wa-cta');
 if(waCta){
 waCta.addEventListener('click',()=>{
 window.open(
 'https://wa.me/27729998863?text='+
 encodeURIComponent("Hi Stopher,I\u2019d like to discuss a project with you."),
 '_blank'
);
});
}
 function setLoading(on){
 btn.disabled=on;
 btn.classList.toggle('loading',on);
 if(spinner)spinner.style.display=on ? 'block' : 'none';
 if(label)label.textContent=on ? 'Sending\u2026' : 'Send Message';
}
 function showStatus(type,html){
 status.className='form-status-msg '+type;
 status.innerHTML=html;
 status.style.display='block';
 status.scrollIntoView({behavior: 'smooth',block: 'nearest'});
}
 function hideStatus(){
 status.style.display='none';
}
 form.addEventListener('submit',async e=>{
 e.preventDefault();
 hideStatus();
 const fd=new FormData(form);
 lastFormData=fd;
 const botcheck=form.querySelector('[name="botcheck"]');
 const websiteUrl=(fd.get('website_url')||'').trim();
 if((botcheck&&botcheck.checked)||websiteUrl){
 showStatus('success','\u2713 Message received!I\u2019ll get back to you within 24 hours.');
 form.reset();
 return;
}
 const name=(fd.get('name')||'').trim();
 const email=(fd.get('email')||'').trim();
 const message=(fd.get('message')||'').trim();
 if(!name||!email||!message){
 showStatus('error','\u26a0 Please fill in all required fields.');
 return;
}
 if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)){
 showStatus('error','\u26a0 Please enter a valid email address.');
 return;
}
 setLoading(true);
 try{
 const res=await fetch('https://api.web3forms.com/submit',{
 method: 'POST',
 body: fd,
 headers:{Accept: 'application/json'},
});
 const data=await res.json();
 if(res.ok&&data.success){
 if(label)label.textContent='\u2713 Sent!';
 btn.style.background='#00e5a0';
 btn.style.boxShadow='0 8px 32px rgba(0,229,160,0.4)';
 btn.disabled=false;
 btn.classList.remove('loading');
 if(spinner)spinner.style.display='none';
 showStatus('success',"\u2713 Message received!I\u2019ll get back to you within 24 hours.");
 form.reset();
 setTimeout(()=>{
 if(label)label.textContent='Send Message';
 btn.style.background='';
 btn.style.boxShadow='';
},4000);
}else{
 throw new Error('submission_failed');
}
}catch{
 setLoading(false);
 const waName=(lastFormData.get('name')||'').trim();
 const waMsg=(lastFormData.get('message')||'').trim();
 const waLink='https://wa.me/27729998863?text='+
 encodeURIComponent(`Hi Stopher,I\u2019m ${waName}\u2014 ${waMsg}`);
 showStatus(
 'error',
 `\u26a0 Something went wrong. `+
 `<a href="${waLink}" target="_blank" rel="noopener" `+
 `style="color:var(--cyan);text-decoration:underline">Try WhatsApp \u2192</a>`
);
}
});
 form.querySelectorAll('input,textarea,select').forEach(el=>{
 el.addEventListener('input',()=>{
 if(status.classList.contains('error'))hideStatus();
});
});
})();